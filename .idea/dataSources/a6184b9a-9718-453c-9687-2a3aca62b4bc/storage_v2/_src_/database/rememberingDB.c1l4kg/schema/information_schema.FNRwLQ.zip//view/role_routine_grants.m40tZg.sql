create view role_routine_grants
            (grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
             routine_name, privilege_type, is_grantable)
as
SELECT grantor,
       grantee,
       specific_catalog,
       specific_schema,
       specific_name,
       routine_catalog,
       routine_schema,
       routine_name,
       privilege_type,
       is_grantable
FROM information_schema.routine_privileges
WHERE (grantor::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles))
   OR (grantee::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles));

alter table role_routine_grants
    owner to ayushparekh;

grant select on role_routine_grants to public;

